@extends('layout.master')

@section('title', 'SASA | Home')
<body>
<div></div>
<div class="container">
  <div class="row">
    <div class="col-sm-12">
<<<<<<< HEAD
      <h1>.............</h1>
=======
>>>>>>> 1808107010047
      <h1>Wortel Paling Enak</h1>
      <div class="row">
        <div class="col-6 col-sm-6">
          <img src="{{url('assets/img/wortel.jpg')}}" width="100%" height="500">
        </div>
        <div class="col-6 col-sm-6 text-black">
          <h6><b>RINCIAN SAYUR</b></h6>
          <div class="row">
          	<div class="col-6 col-sm-6">
          		<b>Nama Sayur</b>
          	</div>
          	<div class="col-6 col-sm-6">
          		Wortel Mantap
          	</div>
          </div>
          	 <div class="row">
          	<div class="col-6 col-sm-6">
          		<b>Harga</b>
          	</div>
          	<div class="col-6 col-sm-6">
          		Rp. 12.000,00
          	</div>
          </div>
          <div class="row">
          	<div class="col-6 col-sm-6">
          		<b>Freshstate</b>
          	</div>
          	<div class="col-6 col-sm-6">
          		Cukup Segar
          	</div>
          </div>
          <div class="row">
          	<div class="col-6 col-sm-6">
          		<b>Nama Pasar</b>
          	</div>
          	<div class="col-6 col-sm-6">
          		Pasar Peunayong
          	</div>
          	<br> <br> <h6> <b>PENJELASAN MENGENAI SAYURAN</b> </h6> <br>
          <p>Wortel merupakan tanaman biennial yang menyimpan karbohidrat dalam jumlah yang besar. Tanaman ini dikenal sebagai sumber vitamin A, selain itu juga memiliki kandungan yang banyak dari vitamin B dan vitamin C. Kandungan vitamin A dalam tanaman sayur ini dapat digunakan untuk kesehatan mata. Mengkonsumsi wortel sangat baik untuk kesehatan mata terutama dapat meningkatkan penglihatan pada jarak jauh. Selain itu, ia juga mengandung vitamin B1, B2, B3, B6, B9 dan kalsium, zat besi, magnesium, fosfor, kalium serta sodium, sehingga baik untuk kesehatan.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>